#!/usr/bin/env bash

cd `dirname $0`

export LD_LIBRARY_PATH=.

[ -t 1 ] && . colors

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR


#try to release TIME_WAIT sockets
while true; do
	#Drop TIME_WAIT sockets
	if [[ $(lsmod | grep droptcpsock) ]]; then
		echo ""
		while true; do
			sockets=$(netstat -n | grep ":$CUSTOM_API_PORT " | grep WAIT)
			[[ -z $sockets ]] && break
			echo -e "${WHITE}Trying to release TIME_WAIT sockets:${NOCOLOR}\n$sockets\n"
			echo "$sockets" | awk '{print $4"\t"$5}' >/proc/net/tcpdropsock
			sleep 1
		done
	fi

	for con in `netstat -anp | grep TIME_WAIT | grep $CUSTOM_API_PORT | awk '{print $5}'`; do
		killcx $con lo
	done
	netstat -anp | grep TIME_WAIT | grep $CUSTOM_API_PORT && continue || break
done


$CUSTOM_DIR/$CUSTOM_NAME | tee --append ${CUSTOM_LOG_BASENAME}.log
