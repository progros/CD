#!/usr/bin/env bash

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

stats_raw=`curl --connect-timeout 2 --max-time 2 --silent --noproxy '*' http://127.0.0.1:$CUSTOM_API_PORT/api.json`
#echo "$stats_raw"
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:${CUSTOM_API_PORT}${NOCOLOR}"
else
	#echo "$gpu_stats"
	khs=$(jq -r '.hashrate.total[0]/500' <<< "$stats_raw")
	#local temp=$(jq '.temp' <<< $gpu_stats)
	#local fan=$(jq '.fan' <<< $gpu_stats)
	local ac=$(jq '.results.shares_good' <<< "$stats_raw")
	local rj=$(( $(jq '.results.shares_total' <<< "$stats_raw") - $ac ))

	local arr=(`jq -r '.brand, .busids, .fan, .temp | join(";")' <<< "$gpu_stats"`)
	local brands=(${arr[0]//;/ })
	local busids=(${arr[1]//;/ })
	local fans=(${arr[2]//;/ })
	local temps=(${arr[3]//;/ })
	local buses=
	local fan=
	local temp=
	for((i=0; i < ${#busids[@]}; i++)); do
		[[ ! ${brands[$i]} == "amd" ]] && continue
		[[ ! -z $buses ]] && buses+="," && temp+="," && fan+=","
		buses+="$((0x${busids[$i]%:*}))"
		fan+="${fans[$i]}"
		temp+="${temps[$i]}"
	done
	buses="[$buses]"
	fan="[$fan]"
	temp="[$temp]"
	
	# .hashrate.threads[][0]]
	local values=(`jq -r -c '.hashrate.threads[][0]' <<< "$stats_raw"`)
	local hashrate=
	for((i=0; i < ${#values[@]}; i=i+2)); do
		[[ ! -z $hashrate ]] && hashrate+=","
		hashrate+=$(( 2 *( ${values[$i]%.*} + ${values[$((i+1))]%.*} ) ))
	done
	hashrate="[$hashrate]"
	echo "$buses / $hashrate / $fan / $temp"

	stats=$(jq --argjson temp "$temp" --argjson fan "$fan" --argjson hs "$hashrate" --argjson bus_numbers "$buses" --arg ac "$ac" --arg rj "$rj" \
		'{$hs, algo: "cryptonight-bbc", $temp, $fan, uptime: .connection.uptime,
		  ar: [$ac, $rj], ver: .version, $bus_numbers}' <<< "$stats_raw")
fi

	[[ -z $khs ]] && khs=0
	[[ -z $stats ]] && stats="null"
