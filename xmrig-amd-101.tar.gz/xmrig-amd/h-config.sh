#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

#. $RIG_CONF

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

conf=`cat /hive/miners/custom/${CUSTOM_NAME}/config_global.json | envsubst`


#merge user config options into main config
if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
	while read -r line; do
		[[ -z $line ]] && continue
			conf=$(jq -s '.[0] * .[1]' <<< "$conf {$line}")
	done <<< "$CUSTOM_USER_CONFIG"
fi

[[ -z $conf || $conf == '[]' || $conf == 'null' ]] && echo -e "${RED}Error in \"Extra config arguments\" value, check your Miner Config please.${NOCOLOR}" && exit 1

#add api port to main config
port=$CUSTOM_API_PORT
port=`jq --null-input --arg port "$port" '{$port}'`
api=$(jq -s '.[0].api * .[1]' <<< "$conf $port")
api=`jq --null-input --argjson api "$api" '{"api": $api}'`
conf=$(jq -s '.[0] * .[1]' <<< "$conf $api")

#merge pools into main config
pools='[]'
tls=$(jq -r .tls <<< "$conf")
[[ -z $tls || $tls == "null" ]] && tls="false"
tls_fp=$(jq -r '."tls-fingerprint"' <<< "$conf")
[[ -z $tls_fp || $tls_fp == "null" ]] && tls_fp="null"
variant=$(jq -r '."variant"' <<< "$conf")
[[ -z $variant || $variant == "null" ]] && variant=-1
rig_id=$(jq -r '."rig-id"' <<< "$conf")
[[ -z $rig_id || $rig_id == "null" ]] && rig_id="$WORKER_NAME"
nicehash=$(jq -r .nicehash <<< "$conf")
[[ -z $nicehash || $nicehash == "null" ]] && nicehash="true"


for url in $CUSTOM_URL; do
	pool=$(cat <<EOF
		{"coin": "bbc", "url": "$url", "user": "$CUSTOM_TEMPLATE", "pass": "$CUSTOM_PASS", "rig-id": "$rig_id", "nicehash": $nicehash, "tls": $tls, "tls-fingerprint": $tls_fp, "variant": "$variant", "keepalive": false }
EOF
)
	pools=`jq --null-input --argjson pools "$pools" --argjson pool "$pool" '$pools + [$pool]'`
done

if [[ -z $pools || $pools == '[]' || $pools == 'null' ]]; then
	echo -e "${RED}No pools configured, using default${NOCOLOR}"
else
	pools=`jq --null-input --argjson pools "$pools" '{"pools": $pools}'`
	conf=$(jq -s '.[0] * .[1]' <<< "$conf $pools")
fi

[[ -z $conf || $conf == '[]' || $conf == 'null' ]] && echo -e "${RED}Error in \"Pool URL\" value, check your Miner Config please.${NOCOLOR}" && exit 1


count=`gpu-detect AMD`
intensity=`grep -oP "\"intensity\"[^0-9]+\K[0-9]+" <<< "$CUSTOM_USER_CONFIG"` && echo "Setting intensity $intensity to $count GPU"
json=`jq -r -c ".opencl.cn|.[]" <<< "$conf"`
out=
for((i=0; i<count; i++)); do
	[[ ! -z $intensity ]] &&
		str=`jq -c ".index=$i | .intensity=$intensity" <<< "$json"` ||
		str=`jq -c ".index=$i" <<< "$json"`
	out=$(jq -s -c '.[0] + .[]' <<< "$out $str")
done
json=$(jq -s . <<< "$out")
gpu=`jq --null-input --argjson gpu "$json" '{"opencl": { "cn/2": $gpu }}'`
conf=`jq -s '.[0] * .[1]' <<< "$conf $gpu"`

[[ -z $conf || $conf == '[]' || $conf == 'null' ]] && echo -e "${RED}Error in \"GPU settings\" value, check your Miner Config please.${NOCOLOR}" && exit 1

echo $conf | jq . > $CUSTOM_CONFIG_FILENAME


